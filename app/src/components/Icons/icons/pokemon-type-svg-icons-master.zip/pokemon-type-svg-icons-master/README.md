## Pokemon Type SVG Icons

![Screenshot](https://i.imgur.com/IU5YvgT.png "Screenshot")

Very simple set of SVG icons for Pokemon types for any use.

See them in action [here](https://duiker101.github.io/pokemon-type-svg-icons/index.html): 

[Original source](https://dribbble.com/shots/4862612-Pokedex-iOS-app)

[Download](https://github.com/duiker101/pokemon-type-svg-icons/releases/tag/1.0.0)
